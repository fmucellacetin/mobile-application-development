package com.rbader.currencyconverter.Activities;

import com.rbader.currencyconverter.ExchangeRates.ExchangeRateDatabase;

public interface ExchangeRateDatabaseActivity {
    void setExchangeRateDatabase(ExchangeRateDatabase exchangeRateDatabase);
}
