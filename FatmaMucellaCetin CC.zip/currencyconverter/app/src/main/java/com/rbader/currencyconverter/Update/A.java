package com.rbader.currencyconverter.Update;

import com.rbader.currencyconverter.ExchangeRates.ExchangeRateDatabase;

public interface A {

    public ExchangeRateDatabase getExchangeRateDatabase();
}
